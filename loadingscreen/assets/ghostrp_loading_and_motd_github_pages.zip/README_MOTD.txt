GHOST RP: GitHub Pages (Loading Screen + MOTD)

This package contains:
- Root / : Loading screen (sv_loadingurl points here)
- /motd/ : MOTD page (clickable buttons + tabs)

1) Loading Screen (server.cfg)
  sv_loadingurl "https://YOURNAME.github.io/REPO/"

2) MOTD URL
Use any MOTD addon (or your own DHTML panel) and set the URL to:
  https://YOURNAME.github.io/REPO/motd/

Notes:
- MOTD reads ../config.json to reuse discordText + websiteText.
- Your discordText can be like: "DISCORD: https://discord.gg/xxxx"
